//Designing  loader
$("body").append("<div class='loader'><span class='red'></span><span class='gold'></span><span class='green'></span></div>");
$(".loader").hide();
$(".all").click(function(evt){
	$(this).children("img").toggleClass('rotate');
evt.preventDefault();
$("em div").slideToggle();
})//end click

$(".deskcat").hover(function(){
$(".deskcat1").slideDown();
$(this).children("img").toggleClass('rotate');
},function(){
$(".deskcat1").slideUp();
$(this).children("img").toggleClass('rotate');
});//end hover

$(".menu_img").click(function(){
$(".menu1 em").fadeToggle();
})//end click
$("aside,article").click(function(){
$(".cat3").fadeOut();
})//end click

$('.h1').each(function(){
    $(this).children('#rateYo').rateYo({
     starWidth:'20px',
     readOnly:true,
     ratedFill:'yellow'
    })
    var rate = $(this).children('em').text();
    $(this).children('#rateYo').rateYo('rating',rate);
	})//end each

//for navigating between the ajax cart and functionalities
if(home){
  var ajax = "php/ajax_cart.php";
  var shop = "php/ajax_shop_cart.php";
  var smartCart = "php/newCart.php";
  var home2 = 'yes';
}else{
  var ajax = "ajax_cart.php";
  var shop = "ajax_shop_cart.php";
  var smartCart = "newCart.php";
  var home2 = 'no';
}


$("body").on('click','.add',function(){
      var numba = $(this).prev("em").text();
      var id = $(this).attr("id");
      numba = Number(numba);
      numba = numba + 1;
       if(numba > 0){
      $(this).prev("em").prev("span").show();
      }
      $(this).prev("em").text(numba);
      var query = 'id='+id+'&quantity='+numba;
      $.post(ajax,query);
     })//end add

 $("body").on('click','.minus',function(){
      var numba = $(this).next("em").text();
      var id = $(this).attr("id");
      numba = Number(numba);
      numba = numba - 1;
      if(numba < 1){
      $(this).hide();
      }
      $(this).next("em").text(numba);
      var query = 'id='+id+'&quantity='+numba;
      $.post(ajax,query);
     })//end minus

     $(".cart1").click(function(){
      $(".nav4").fadeToggle();
     })//end click

$("body").on('click','.closer',function(){
$(".nav4").fadeOut();
})//end click

$("body").on('click','.add_to_cart',function(evt){
  evt.preventDefault();
var product_id = $(this).attr('id');
var query = "id="+product_id;
var animate = true;
var cart_b = Number($(".cat1 b").html());
if(animate){
  $(".loader").show();
  setInterval(load,1000);
}
$.post(shop,query,function(data){
 animate = false;
 $(".loader").hide();
  alert(data);
cart_b ++;
$(".cat1 b").html(cart_b);

});

var query2 = 'home1='+home2;
$.post(smartCart,query2,function(data){
$(".nav4").html(data);
});
})//end click

function load(){
  $(".red").fadeOut().fadeIn();
  $(".gold").fadeOut().fadeIn();
  $(".green").fadeOut().fadeIn();
}

