<?php
$home = 'php/error.php';//if home provide different link to error
require "php/all_functions.php";// Contains most functions and data needed for the functioning of this site
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Stor1, Clothes and accessories</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="css/index2.css">
	<link rel="stylesheet" type="text/css" href="css/fixed.css">
	<script src="js/jquery.js"></script>
	<style>
.leftslide img{
width: 20px;
border-radius: 50%;
}
.rightslide img{
	width: 20px;
	border-radius: 50%;
}
header{
	padding-bottom: 20px;
}
.le,.re{
	position: static;
	margin-left: 40px;
	margin-bottom: -10px;
	display: inline-block;
}
header form{
	margin-bottom: -20px!important;
}
@media(min-width: 1000px){
	header{
	margin-bottom: 0px;
}
.leftslide img{
width: 30px;
}
.rightslide img{
	width: 30px;
}
}
</style>
</head>
<body>
<header>
	<?php   
  navigations($home = true, $top = true);
	?>
</header>
<article id="article">
<div class="divslide">
	<span class="leftslide"><img src="img/left.jpg"></span>
	<span class="rightslide"><img src="img/right.jpg"></span>
	<p>
	<a href="#"><img src="img/banner.jpg" class="b1"></a>
	<a href="#"><img src="img/banner1.jpg" class="b1"></a>
	<a href="#"><img src="img/banner2.jpg" class="b1"></a>
    </p>
</div>

<?php
$query_apple = sprintf("SELECT * FROM products WHERE categories='Men shirts' ORDER BY id DESC limit 27;");
$result_apple = mysqli_query($conn,$query_apple);
if(mysqli_num_rows($result_apple) != 0){
	echo "<a href='#' class='cate'>Best deals<span class='leftslide le'><img src='img/left.jpg'></span>
	<span class='rightslide re'><img src='img/right.jpg'></span>";

	echo "</a><span class='productSlides'><h5 id='touch' style='font-weight:normal;font-size:15px;'>";
	while($row_apple = mysqli_fetch_array($result_apple)){
		$products2 = $row_apple['product'];
	
		$pro2 = $products2;
		if(strlen($products2) > 15){
		$products2 = substr($products2, 0,10).'...';
	}
		$price2 = $row_apple['price'];
		$id2 = $row_apple['id'];
		$img2 = $row_apple['img1'];
		$img2 = explode('../', $img2);
		$img2 = $img2[1];
		
		echo "<a href='php/view.php?id=$id2' class='products'>
           <img src='$img2'>
          <br><b>$products2</b><br>
           <em>GHS $price2</em><br>
           <em class='add_to_cart' id='$id2'>Add to cart</em></a>";
	}
}
?>
</h5>
</span>

<aside>
<?php
$query_apple = sprintf("SELECT * FROM products WHERE categories='Men shoes' ORDER BY id DESC limit 24;");
$result_apple = mysqli_query($conn,$query_apple);
if(mysqli_num_rows($result_apple) != 0){
	echo "<a href='#' class='cate'>Pets</a>";
	while($row_apple = mysqli_fetch_array($result_apple)){
		$products2 = $row_apple['product'];
		$pro2 = $products2;
		if(strlen($products2) > 15){
		$products2 = substr($products2, 0,10).'...';
	}
		$price2 = $row_apple['price'];
		$id2 = $row_apple['id'];
		$img2 = $row_apple['img1'];
		$img2 = explode('../', $img2);
		$img2 = $img2[1];
		
		echo "<a href='php/view.php?id=$id2' class='products'>
           <img src='$img2'>
           <br><b>$products2</b><br>
           <em>GHS $price2</em><br>
           <em class='add_to_cart' id='$id2'>Add to cart</em></a>";
	}
}
?>
</aside>
</article>
<h6>.</h6>
<footer>
	<?php
  navigations($home = true, $top = false);//navgation function
	?>
</footer>
</body>
<script>
	var home = true;
</script>
<script src="js/all.js"></script>
<script>
$(document).ready(function(){

//Slides functionalities just bellow
var countSlides = 1;
$(".leftslide").hide();
function slide(){
	$(".leftslide, .rightslide").show();
if(countSlides == 1){
	//slideshow second and increment counter + others
	$("article div p,.productSlides h5").animate({
     'margin-left':'-100%'
	});
	countSlides = 2;
}else if(countSlides == 2){
$("article div p,.productSlides h5").animate({
     'margin-left':'-200%'
	});
$(".rightslide").hide();
countSlides = 3;
}else if(countSlides == 3){
	$("article div p,.productSlides h5").animate({
     'margin-left':'0%'
	});
	countSlides = 1;
	$(".leftslide").hide();
}
}

$(".leftslide").click(function(e){
	e.preventDefault();
if(countSlides != 1){
	if(countSlides == 2){
		$("article div p,.productSlides h5").animate({
     'margin-left':'0%'
	});
		countSlides = 1;
	}else if(countSlides == 3){
     $("article div p,.productSlides h5").animate({
     'margin-left':'-100%'
	});
     countSlides = 2;
	}
}
})//end click
$(".rightslide").click(function(e){
	e.preventDefault();
if(countSlides != 3){
	if(countSlides == 2){
		$("article div p,.productSlides h5").animate({
     'margin-left':'-200%'
	});
		countSlides = 3;
	}else if(countSlides == 1){
     $("article div p,.productSlides h5").animate({
     'margin-left':'-100%'
	});
     countSlides = 2;
	}
}
})//end click

setInterval(slide,10000);

//Manupulating the slides with touch event

var at = document.getElementById('touch');
var iniX;
at.addEventListener("touchstart",start);
at.addEventListener("touchmove",move);
function start(e){
iniX = e.touches[0].clientX;
}
function move(e){
	if(iniX === null){
		return;
	}

var currentX = e.touches[0].clientX;
var difX = currentX - iniX;

if(difX > 0){//swipe right
if(countSlides != 1){
	if(countSlides == 2){
		$(".productSlides h5").animate({
     'margin-left':'0%'
	});
		countSlides = 1;
	}else if(countSlides == 3){
     $(".productSlides h5").animate({
     'margin-left':'-100%'
	});
     countSlides = 2;
	}
}
}else{
if(countSlides != 3){
	if(countSlides == 2){
		$(".productSlides h5").animate({
     'margin-left':'-200%'
	});
		countSlides = 3;
	}else if(countSlides == 1){
     $(".productSlides h5").animate({
     'margin-left':'-100%'
	});
     countSlides = 2;
	}
}
}
iniX = null;
}
})//end ready
</script>
</html>