<?php
require "all_functions.php";
if(!$_SESSION['admin']){
	header("location:../index.php");
}
if($_REQUEST['password']){
	trim($password = $_REQUEST['password']);
}
$query = sprintf("UPDATE ad_pass SET pass='%s';",mysqli_real_escape_string($conn,$password));
$result = mysqli_query($conn,$query);
if($result){
	header("location:admin.php?success=Operation successful");
}
?>