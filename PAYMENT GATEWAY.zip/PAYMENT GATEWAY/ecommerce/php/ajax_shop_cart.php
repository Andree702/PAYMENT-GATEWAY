<?php
require "all_functions.php";

$id = $_REQUEST['id'];
if($id){
if(!$_SESSION['cart']){
	$_SESSION['cart'] = [];
}
if(isset($_SESSION['cart'][$id])){
	$_SESSION['cart'][$id]++;
}else{
$_SESSION['cart'][$id] = 1;
}
}
if($_SESSION['cart'][$id]){
	echo "Product added to cart";
}

?>