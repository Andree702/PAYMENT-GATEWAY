<?php
require "all_functions.php";
if(!$_SESSION['admin']){
	header("location:../index.php");
}
$id = $_REQUEST['id'];
$query = sprintf("DELETE FROM orders WHERE order_id = %d;",$id);
$result = mysqli_query($conn,$query);
header("location:admin.php?success=Operation successful");
?>