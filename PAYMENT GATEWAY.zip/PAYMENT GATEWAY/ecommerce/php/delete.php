<?php
require "all_functions.php";
if(!$_SESSION['admin']){
	header("location:../index.php");
}
$id = $_REQUEST['id'];
$query = sprintf("DELETE FROM products WHERE id=%d;",mysqli_real_escape_string($conn,$id));
$result = mysqli_query($conn,$query);
if($result){
	$row = mysqli_fetch_array($result);
	$img1 = $row['img1'];
	$img2 = $row['img2'];
	unlink($img1);
	unlink($img2);
	header("location:admin.php?success=Opertaion succesful");
}
?>