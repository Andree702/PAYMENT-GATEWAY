<?php
require "all_functions.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Checkout</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/fixed.css">
	<link rel="stylesheet" type="text/css" href="../css/checkout.css">
	<script src="../js/jquery.js"></script>
	<style>
		article table{
			margin-right: 40px;
		}
		article div p{
			font-weight: bold;
			font-family: verdana;
		}
		.cat1{
			display: none;
		}
	</style>
</head>
<body>
	<header>
<?php
navigations($home = false, $top = true);
?>
	</header>
	<article>
		<div>
	<table>
<?php
if($_SESSION['cart']){
	$total = 0;
	echo "<tr><th>ITEM</td><th>PRICE</td><th>QUANTITY</td><th>TOTAL</td></tr>
	";
foreach ($_SESSION['cart'] as $key => $value) {
	$query = sprintf("SELECT * FROM products WHERE id = %d;",$key);
	$result = mysqli_query($conn,$query);
	$row = mysqli_fetch_array($result);
	$product = htmlentities($row['product']);
	$img1 = htmlentities($row['img1']);
	$price = $row['price'];
	$total_amount = $price * $value;
	$total += $total_amount;
	echo "<tr><td>$product</td><td>$price</td><td>$value</td><td>$total_amount</td>
	";
}
echo "</tr><tr><td colspan=3>Sub-total</td><td>$total</td></tr>";
}
?>
</table>
</div>
<div><p>Are you a user already? login to buy.</p>
<form action="process_checkout.php" method="post">
	<ul>
		<li>
			<label>Email</label>
			<input type="email" name="email" required>
		</li>
		<li>
			<label>Password</label>
			<input type="password" name="password" required>
		</li>
		<li>
			<input type="submit" value="Login to buy">
		</li>
	</ul>
</form>
</div>
<div>
<p>Or add your details below to complete order</p>
<form action="process_signcheck.php" method="post">
	<ul>
		<li>
			<label>Full Name</label>
			<input type="text" name="name"  required>
		</li>
		<li>
			<label>Telephone number to call</label>
			<input type="tel" name="number" required>
		</li>
		<li>
			<label>Location</label>
			<input type="text" name="location" required>
		</li>
		<li>
			<label>Last bus-stop to your delivery location</label>
			<input type="text" name="bus" required>
		</li>
		<li>
			<input type="submit" value="Buy now">
		</li>
	</ul>
</form>
</div>
</article>
<footer>
	<?php
navigations($home = false, $top = false);
?>
</footer>
</body>
<script>
	var home = false;
</script>
<script src='../js/all.js'></script>
<script>
	$(document).ready(function(){
		function mail(data){
         if(data == 'yes'){
         	$(".sub").attr('disabled','yes');
         	$(".email").addClass("blur");
         	$(".lab").text("Email is already in used");
         	$(".lab").css('color','red');
         }else{
         	$(".sub").attr('disabled',false);
         	$(".email").removeClass("blur");
         	$(".lab").text("Email");
         	$(".lab").css('color','grey');
         }
        }
         $('.email').blur(function(){
     var content = $(".email").val();
     var query = "email=" + content;
     $.post('unique.php',query,mail);
    })
	})//end ready
</script>
</html>