<?php 
require "all_functions.php";
if(!isset($_SESSION['id'])){
	if(isset($_POST['email'])){
		$email = trim($_POST['email']);
		$password = trim($_POST['password']);
		$query = sprintf("SELECT * FROM users WHERE email='%s' AND password = '%s';",mysqli_real_escape_string($conn,$email),mysqli_real_escape_string($conn,$password));
		$result = mysqli_query($conn,$query);
		if(mysqli_num_rows($result) != 0){
        $row = mysqli_fetch_array($result);
        $id  = $row['id'];
        $name = $row['name'];
        $contact = $row['number'];
        $_SESSION['id'] = $id;
        $_SESSION['name'] = $name;
        $_SESSION['contact'] = $contact;
        header("location:profile.php");
		}else{
			$erro  = 'Incorrect email or password';
		}
	}

}else{
	header("location:profile.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/fixed.css">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<script src="../js/jquery.js"></script>
	<style>
		.error{
			text-align: center;
			margin-top: 10px;
			font-family: sans-serif;
			color: red;
			font-size: 14px;
		}
		</style>
</head>
<body>
<header>
<?php
navigations($home = false, $top = true);
?>
</header>	
<article>
<?php
	if(isset($erro)){
	echo "<p class='error'>$erro</p>";
	}else{
		echo '';
	}
	?>
<form action="login.php" method="post">
<ul>
	<li>
		<label>Email</label>
		<input type="email" name="email">
	</li>
	<li>
		<label>Password</label>
		<input type="password" name="password">
	</li>
	<li>
		<input type="submit" value="Log in">
	</li>
</ul>	

</form>
<p><a href="forget.php">Forget password?</a></p>
</article>

<footer>
	<?php
navigations($home = false, $top = false);
?>
</footer>
</body>
<script>
	var home = false;
</script>
<script src='../js/all.js'></script>
</body>
</html>