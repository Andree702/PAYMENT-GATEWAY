<?php
require "all_functions.php";
if(!isset($_SESSION['admin'])){
	if(isset($_POST['password'])){
		trim($password = $_POST['password']);
		$query = sprintf("SELECT * FROM ad_pass WHERE pass = '%s';",mysqli_real_escape_string($conn,$password));
		$result = mysqli_query($conn,$query);
		if(mysqli_num_rows($result) != 0){
        $row = mysqli_fetch_array($result);
        $pass  = $row['pass'];
        $_SESSION['admin'] = $pass;
        header("location:admin.php");
		}else{
			$erro  = 'Incorrect password';
		}
	}

}else{
	header("location:admin.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<style>
		.error{
			text-align: center;
			margin-top: 10px;
			margin-bottom: -10px;
			font-size: 14px;
			color: red;
			font-family: sans-serif;
		}
		input[type='password']{
			padding-left: 5px;
		}
		h1{
			text-align: center;
			font-style: italic;
			margin-top: 30px;
		}
		form{
			text-align: center;
			padding-top: 20px;
		}
		form *{
			margin-left: 0px;
			box-sizing: border-box;
			padding: 0px;
			margin: 0px;
		}
		article {
			box-sizing: border-box;
			padding: 0px;
		}
	</style>
</head>
<body>
	<h1>ADMIN</h1>
	<?php
	if($erro){
	echo "<p class='error'>$erro</p>";
	}
	?>
	<article>
<form method="post" action="admin_auth.php">
	<ul>
		<li>
	<input type="password" name="password" placeholder="password">
	</li>
	<li>
	<input type="submit" value="Log in">
	</li>
	</ul>
</form>
</article>
</body>
</html>