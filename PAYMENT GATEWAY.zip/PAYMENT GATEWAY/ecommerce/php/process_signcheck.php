<?php
require "all_functions.php";
$name = $_REQUEST['name'];
$number = $_REQUEST['number'];
$location = $_REQUEST["location"];
$bus = $_REQUEST["bus"];

$date = date("Y-m-d h:i:s");

if($name){
	foreach ($_SESSION['cart'] as $key => $value) {
		if($_SESSION['colourer'][$key]){
		$colour = $_SESSION['colourer'][$key];
	}else{
       $colour = '';
	}
	if( $_SESSION['sizer'][$key]){
	$size = $_SESSION['sizer'][$key];
}else{
	$size = '';
}
		$query_order = sprintf("INSERT INTO orders(product_id,sizes,colours,quantity,date,name,number,location,bus) VALUES(%d,'%s','%s',%d,'%s','%s','%s','%s','%s');",$key,$size,$colour,$value,$date,mysqli_real_escape_string($conn,$name),mysqli_real_escape_string($conn,$number),mysqli_real_escape_string($conn,$location),mysqli_real_escape_string($conn,$bus));
		$result_order = mysqli_query($conn,$query_order);
	}
	unset($_SESSION['cart']);
	unset($_SESSION['colourer']);
	unset($_SESSION['sizer']);
header("location:confirmation.php?name=$name");

}else{
	header("location:error.php?from=signup.php&error=Empty form field(Name)");
}
?>