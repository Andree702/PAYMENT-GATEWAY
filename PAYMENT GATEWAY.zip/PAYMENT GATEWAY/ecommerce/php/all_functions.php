<?php
session_start();
error_reporting(0);//clear this on upload
require 'config.php';
require 'database_connect.php';
$total_items = count($_SESSION['cart']);
//The below variable set the theme for the application
//All pages must require the this file and call the below variable in the theme color content
$theme = 'blue';
//functions for both headers and footers
function navigations($home = false, $top = false){
  if($home){
    $link = "php/";
    $link2 = "img/";
  }else{
    $link = "";
    $link2 = "../img/";
  }
  require 'database_connect.php';
  global $total_items;


  if($top){
  echo '
    <nav class="nav1">
     <ul>
     <li class="gh">GHS<img src="'.$link2.'map.png"></li>
     <span>
     <li><a href="'.$link.'login.php">Login</a></li>
     <li><a href="'.$link.'signup.php">Sign up</a></li>
     <span>
     </ul>
    </nav><nav class="nav3"><ul class="cartside">';

    if($home){
     echo '<li><img src="'.$link2.'logo.png" class="logo"></li>';
    }else{
       echo '<li><a href=../index.php><img src="'.$link2.'logo.png" class="logo"></a></li>';
    }
    echo "<li class='call'>Place order(+34445555)</li>";
     echo '<li class="mob cart1"><a href="#"> <a href="#" class="cat1">
        <img src="'.$link2.'basket.png">
        <b class="cart">'.$total_items.'</b>
        </a>
</a></li>
     <span>
     <li class="desk cart1"><a href="#"> <a href="#" class="cat1">
        <img src="'.$link2.'basket.png">
        <b class="cart">'.$total_items.'</b>
        </a>
</a></li>
</span>
     </ul>
    </nav>
    <nav class="nav4"><table>';
     if($_SESSION['cart']){
      $total = 0;
foreach ($_SESSION['cart'] as $key => $value) {
  $query = sprintf("SELECT * FROM products WHERE id = %d;",$key);
  $result = mysqli_query($conn,$query);
  $row = mysqli_fetch_array($result);
  $product = htmlentities($row['product']);
  $img1 = htmlentities($row['img1']);
  if($home){
   $img1 = substr($img1, 3);
  }
  
  $price = $row['price'];
  $total_amount = $price * $value;
  $total += $total_amount;
  $_SESSION['total'] = $total;
  echo "<tr>
  <td><a href='".$link."view.php?id=$key'><img src='$img1'></a></td><td><a href=''.$link.'view.php?id=$key'><h3>$product</h3></a></td></tr>
  <tr><td><span class='minus' id='$key'>-</span><em>$value</em><span class='add' id='$key'>+</span></td></tr>";
}
}
echo "<tr><td>Sub-total =</td><td>GHS $total</td></tr></table>";
if(isset($_SESSION['cart'])){
echo "<em class='crt'><a href='".$link."checkout.php'>Checkout</a></em>";
}else{
echo "<em class='crt'><a href='#'>Empty cart</a></em>";
}
echo "<em class='crt closer'><a href='#'>Close cart</a></em>";
echo "</nav>";
}else{
  echo '<ul class="contact mob">
      
      <div><img src="'.$link2.'call.png"><li><a href="#bt"><em>PHONE SUPPORT </em><br><b id="bt">+233243253813</b></a></li></div>
      <div><img src="'.$link2.'email.png"><li><a href="#bt"><em>EMAIL SUPPORT </em><br><b id="bt">wwkpetshop@gmail.com</b></a></li></div>
      </ul>
      <nav>
      <ul>
      <h4>ABOUT US</h4>
      <li><a href="'.$link.'contact.php">About Us</a></li>
      <li><a href="'.$link.'signup.php">Sign up</a></li>
      <li><a href="'.$link.'login.php">Log in</a></li>
      <li><a href="'.$link.'faq.php">FAQ</a></li>
    </ul>
   <ul class="connect">
   <h4>CONNECT WITH US</h4>
      <a href="#" target="_blank"><img src="'.$link2.'fb.png"></a>
     <a href="#" target="_blank"><img src="'.$link2.'ins2.png"></a>
    
   </ul>
   <ul class="contact desk">
   
      <div><img src="'.$link2.'call.png"><li><a href="#bt"><em>PHONE SUPPORT </em><br><b id="bt">+345678978</b></a></li></div>
      <div><img src="'.$link2.'email.png"><li><a href="#bt"><em>EMAIL SUPPORT </em><br><b id="bt">Store1@gmail.com</b></a></li></div>
    
   </ul>
    <p class="copy">Copyright &#169 Store1</p><hr>
  </nav>';
}
}

?>