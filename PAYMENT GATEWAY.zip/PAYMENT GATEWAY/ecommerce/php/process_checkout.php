<?php
require "all_functions.php";
$email = trim($_REQUEST['email']);
$password = trim($_REQUEST['password']);
$date = date("Y-m-d h:i:s");

$query = sprintf("SELECT * FROM users WHERE email='%s' AND password='%s';",mysqli_real_escape_string($conn,$email),mysqli_real_escape_string($conn,$password));
$result = mysqli_query($conn,$query);
if(mysqli_num_rows($result) != 0){
	$row = mysqli_fetch_array($result);
	$id = $row['id'];
	$name = $row['name'];
	foreach ($_SESSION['cart'] as $key => $value) {
		if($_SESSION['colourer'][$key]){
		$colour = $_SESSION['colourer'][$key];
	}else{
       $colour = '';
	}
	if( $_SESSION['sizer'][$key]){
	$size = $_SESSION['sizer'][$key];
}else{
	$size = '';
}
		$query_order = sprintf("INSERT INTO orders(user_id,product_id,sizes,colours,quantity,date) VALUES(%d,%d,'%s','%s',%d,'%s');",$id,$key,$size,$colour,$value,$date);
		$result_order = mysqli_query($conn,$query_order);
	}
	unset($_SESSION['cart']);
	unset($_SESSION['colourer']);
	unset($_SESSION['sizer']);
header("location:confirmation.php?name=$name");
}else{
	header("location:error.php?error=Incorrect email or password&from=checkout.php");
}
?>