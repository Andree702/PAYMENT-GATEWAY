<?php
require "all_functions.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>FAQ</title>
	<meta charset="utf-8">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/faq.css">
	<script src="../js/jquery.js"></script>
</head>
<body>
	<article>
	<header>
		<p id="p">FAQ</p>
	</header>
<h4>How long does it takes to deliver ordered products?</h4>
<p>It depends on the location, But It normally takes less than a day</p>
<h4>Do you give discount to customers?</h4>
<p>Yes, normally to frequent buyers and on special occasions</p>
</article>
<script>
	/*help those with no javascript*/
	$(document).ready(function(){
     $('h4').click(function(){
     $(this).next().fadeToggle(500);
     $(this).toggleClass('display');
     })//end click
	})//end ready
</script>
</body>
</html>