<?php
require "all_functions.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Error</title>
	<meta charset="utf-8">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<meta name="viewport" content="width=device-width">
	<style>
	body *{
		font-family: sans-serif;
	}
	a{
		color: hsl(220,100%,50%);
		text-decoration: none;
		display: block;
	}
		h1{
          margin-top: 70px;
		}
		header{
	background: hsl(0,0%,98%);
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	height: 50px;
	overflow: hidden;
	z-index: 900;
}
header p{
	text-align: center;
	padding-top: 1px;
	font-family: helvetica,sans-serif;
}
	</style>
</head>
<body>
	<header>
		<p>Error</p>
	</header>
<h1>OOPS, Really sorry</h1>
<?php
$error = $_REQUEST['error'];
$from = $_REQUEST['from'];
echo "<p>$error</p>";
echo "<a href='$from'>Go back</a>";
?>
</body>
</html>