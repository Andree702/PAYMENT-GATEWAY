<?php
require 'all_functions.php';
$home = $_REQUEST['home1'];

if($home=='yes'){
	$links = 'php/';
}else{
	$links = '';
}
if($_SESSION['cart']){
	echo "<table>";
      $total = 0;
foreach ($_SESSION['cart'] as $key => $value) {
  $query = sprintf("SELECT * FROM products WHERE id = %d;",$key);
  $result = mysqli_query($conn,$query);
  $row = mysqli_fetch_array($result);
  $product = htmlentities($row['product']);
  $img = htmlentities($row['img1']);
   if($home == 'yes'){
  $img1 = substr($img, 3);
}else{
  $img1 = $img;
}

  $price = $row['price'];
  $total_amount = $price * $value;
  $total += $total_amount;
  echo "<tr>
  <td><a href='".$links."view.php?id=$key'><img src='$img1'></a></td><td><a href='".$links."view.php?id=$key'><h3>$product</h3></a></td></tr>
  <tr><td><span class='minus' id='$key'>-</span><em>$value</em><span class='add' id='$key'>+</span></td></tr>";
}
}
echo "</table>";
if(isset($_SESSION['cart'])){
echo "<em class='crt'><a href='".$links."checkout.php'>Checkout</a></em>";
}else{
echo "<em class='crt'><a href='#'>Empty cart</a></em>";
}
echo "<em class='crt closer'><a href='#'>Close cart</a></em>";

?>