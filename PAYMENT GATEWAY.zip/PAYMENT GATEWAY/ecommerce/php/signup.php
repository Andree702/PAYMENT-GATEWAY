<?php 
require "all_functions.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sign up</title>
	<meta charset="utf-8">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/fixed.css">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<script src="../js/jquery.js"></script>
	<style>
		p{
			text-align: center;
			color: grey;
			font-size: 14px;
			font-family: helvetica,sans-serif;
		}
		p a{
			color: hsl(210,100%,50%);
		}
	</style>
</head>
<body>
<header>
<?php
navigations($home = false, $top = true);
?>
</header>
<article>
<p>By signing up you agree with our <a href="tandc.php"> terms and conditions</a></p>
<form action="process_signup.php" method="post">
	<ul>
		<li>
			<label>Full Name</label>
			<input type="text" name="name"  required autofocus>
		</li>
		<li>
			<label>Password</label>
			<input type="password" name="password" required>
		</li>
		<li>
			<label class="lab">Email</label>
			<input type="email" name="email" required class="email">
		</li>
		<li>
			<label>Telephone number(active number)</label>
			<input type="tel" name="number" required>
		</li>
		<li>
			<label>City</label>
			<input type="text" name="city" required>
		</li>
		<li>
			<label>Town</label>
			<input type="text" name="town" required>
		</li>
		<li>
			<input type="submit" value="Sign up" class="sub">
		</li>
	</ul>
</form>
</article>
<footer>
	<?php
navigations($home = false, $top = false);
?>
</footer>
<script>
	var home = false;
</script>
<script src='../js/all.js'></script>
<script>
	$(document).ready(function(){
     function mail(data){
         if(data == 'yes'){
         	$(".sub").attr('disabled','yes');
         	$(".email").addClass("blur");
         	$(".lab").text("Email is already in used");
         	$(".lab").css('color','red');
         }else{
         	$(".sub").attr('disabled',false);
         	$(".email").removeClass("blur");
         	$(".lab").text("Email");
         	$(".lab").css('color','grey');
         }
        }

    $('.email').blur(function(){
     var content = $(".email").val();
     var query = "email=" + content;
     $.post('unique.php',query,mail);
    })
	})//end ready
</script>
</body>
</html>