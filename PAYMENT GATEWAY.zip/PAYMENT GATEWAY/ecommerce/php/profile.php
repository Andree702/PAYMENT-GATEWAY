<?php
require "all_functions.php";
if(!$_SESSION['id']){
	header("location:../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Profile</title>
	<meta charset="utf-8">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/fixed.css">
	<script src="../js/jquery.js"></script>

	<style>
	header .nav1{
		display: none;
		visibility: hidden;
	}
	.nav2{
		margin-top: 0px;
	}
	.set{
		color: hsl(200,100%,50%);
		margin: 10px;
		display:inline-flex;
		margin-top: -10px;
		margin-bottom: 30px;
	}
		header .logo img{
			vertical-align: middle;
		}
		article{
			margin-bottom: 30px;
		}
		article div{
			width: 300px;
			box-shadow: 2px 2px 3px silver;
			border-bottom-right-radius: 10px;
			border-bottom-left-radius: 10px;
			margin-left: 10px;
			padding: 5px;
			min-height: 60px;
		}
	    article div b{
	    	font-weight: normal;
	    	background: hsl(0,0%,98%);
	    	display: block;
	    	margin-bottom: 10px;
	    	padding:10px;
	    }
		h1{
			margin-top: 30px;
			margin-left: 10px;
			margin-bottom: 20px;
		}
		div a{
			color: grey;
		}
		h1 span{
			color: grey;
			margin-top: -10px;
			display: inline-block;
			font-weight: lighter;
			font-size: 15px;
		}
		.saved{
			padding: 10px;
			width: 300px;
			color: grey;
			margin-top: -20px;
			margin-left: 10px;
		}
		.del_saved{
			color: red;
			margin-top: 10px;
			margin-bottom: 20px;
			margin-left: 30px;
		}
		.del_saved img{
         vertical-align: middle;
		}
		.items{
			margin-left: 10px;
			background: orange;
			color: white;
			font-weight: bold;
			width: 300px;
		
			padding: 5px;
		}
		.msg{
			position: absolute;
			width: 80%;
			left:10%;
			right: 10%;
			text-align: center;
			border-radius: 20px;
			background: black;
			padding:20px;
			color: white;
			margin: auto;

		}
		@media(min-width: 1000px){
			.saved{
			width: 400px;
			margin-top: 20px;
			color: grey;
			margin-left: 10px;
		}
		header{
			box-shadow: 1px 1px 3px silver;
			padding-bottom: 8px;
		}
		.items,article div{
			width: 480px;
		}
		article{
			padding-left: 40px;
		}
		}
	</style>
</head>
<body>
<header>
<?php
navigations($home = false, $top = true);
?>
</header>
<article>
<?php
if($_REQUEST['success']){
	echo "<p class='msg'>".$_REQUEST['success']."</p>";
}
$id = $_SESSION['id'];
$contact = $_SESSION['contact'];
$query = sprintf("SELECT * FROM users WHERE id=%d;",$id);
$result = mysqli_query($conn,$query);
if(mysqli_num_rows($result) != 0){
	$row = mysqli_fetch_array($result);
	$name = htmlentities($row['name']);
	echo "<h1>Welcome $name<br><span>My contact : $contact</span></h1><a href='settings.php' class='set'>Go to settings</a><a href='logout.php' class='set'>Logout</a>";
}
$query_save = sprintf("SELECT * FROM saved WHERE user_id=%d;",$id);
$result_save = mysqli_query($conn,$query_save);
if(mysqli_num_rows($result_save) != 0){
	echo "<p class='items'>Saved products</p><div>";
	while($row_save = mysqli_fetch_array($result_save)){
		$product = $row_save['product'];
		$query_exist = sprintf("SELECT * FROM products WHERE product = '%s';",mysqli_real_escape_string($conn,$product));
		$result_exist = mysqli_query($conn,$query_exist);
		if(mysqli_num_rows($result_exist) < 1){
		continue;
		}
	$id1 = $row_save['product_id'];
	echo "<b><a href='view.php?id=$id1'>$product</a>";
	echo "<a href='del_saved.php?id=$id1' class='del_saved'><img src='../img/log.png'></a></b>";
}
}else{
	echo "<p class='saved'>Your saved products appear here, saved products get removed as soon as they run out of stock</p>";
}
?>
</div>
</article>
<footer>
	<?php
navigations($home = false, $top = false);
?>
</footer>
</body>
<script>
	var home = false;
</script>
<script src='../js/all.js'></script>
<script>
	$(document).ready(function(){
     $(".msg").fadeOut().fadeIn().fadeOut(5000);
     $(".del_saved").click(function(evt){
     var val = confirm("do you really want to delete this?");
     if(!val){
     	evt.preventDefault();
     }
     })//end click
	})//end ready
</script>
</body>
</html>