<?php
require "all_functions.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>About us</title>
	<meta charset="utf-8">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/footer_info.css">
</head>
<body>
<header>
	<p>About us</p>
</header>
<article>
<h1 class="one">Store1</h1>
<ul>
	<li>
   Welcome to store1,Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
   tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
   quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
   consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
   cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
   proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</li>
</ul>
</article>
</body>
</html 