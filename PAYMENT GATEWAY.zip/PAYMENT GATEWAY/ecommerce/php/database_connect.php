<?php
if($home){
	$error = $home;
}else{
	$error = 'error.php';
}
$conn = mysqli_connect(HOST,USER,PASSWORD) or header("location:$error?error=Error connecting to our database server, please try again later&from=../index.php");
mysqli_select_db($conn,DATABASE) or header("location:$error?error=Error connecting to our database server, please try again later&from=../index.php");
?>