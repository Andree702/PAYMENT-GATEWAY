<?php
require "all_functions.php";
if($_REQUEST['product']){
$product = trim($_REQUEST['product']);
$price = trim($_REQUEST['price']);
$brand = trim($_REQUEST['brand']);
$category = trim($_REQUEST['category']);
$sub = trim($_REQUEST['sub']);
$colours = trim($_REQUEST['colours']);
$sizes = trim($_REQUEST['sizes']);
$description = $_REQUEST['description'];
$type1 = $_REQUEST['type'];


$img = 'avatar';
$dir = '../product_images/';

for($a = 0; $a < 2; $a++){
	$type = $_FILES[$img]['type'][$a];
	if(!$type){
		break;
	}
	$now = time();
	while(file_exists($upload = $dir.'_'.$now.$_FILES[$img]['name'][$a])){
		$now++;
	}
if($type == 'image/jpeg'){
$real_image = imagecreatefromjpeg($_FILES[$img]['tmp_name'][$a]);
imagejpeg($real_image,$upload,40);
}elseif($type == 'image/gif'){
$real_image = imagecreatefromgif($_FILES[$img]['tmp_name'][$a]);
imagejpeg($real_image,$upload,40);
}elseif($type == 'image/png'){
$real_image = imagecreatefrompng($_FILES[$img]['tmp_name'][$a]);
imagejpeg($real_image,$upload,40);
}else{
header("location:error.php?from=admin.php&error=Use jpeg or png or gif file");	
}
$_SESSION['images'][$a] = $upload;
}
if($_SESSION['images'][0]){
	$img1 = $_SESSION['images'][0];
}else{
	$img1 = '';
}	
if($_SESSION['images'][1]){
	$img2 = $_SESSION['images'][1];
}else{
$img2 = '';	
}
$query = sprintf("INSERT INTO products(product,categories,sub,brand,price,colours,sizes,description,img1,img2,type) VALUES('%s','%s','%s','%s',%d,'%s','%s','%s','%s','%s','%s');",mysqli_real_escape_string($conn,$product),mysqli_real_escape_string($conn,$category),mysqli_real_escape_string($conn,$sub),mysqli_real_escape_string($conn,$brand),mysqli_real_escape_string($conn,$price),mysqli_real_escape_string($conn,$colours),mysqli_real_escape_string($conn,$sizes),mysqli_real_escape_string($conn,$description),mysqli_real_escape_string($conn,$img1),mysqli_real_escape_string($conn,$img2),mysqli_real_escape_string($conn,$type1));
$result = mysqli_query($conn,$query);

if($result){
	$_SESSION['images'] = [];
	header("location:add.php?success=Product uploaded");

}else{
	die(mysqli_error($conn));
}

}else{
	header("location:error.php?error=Please fill all form field or use small image size");
}
?>