<?php
require "all_functions.php";
$name = $_REQUEST['name'];
$email = trim($_REQUEST['email']);
$number = $_REQUEST['number'];
$password = trim($_REQUEST['password']);
$city = $_REQUEST['city'];
$town = $_REQUEST['town'];

if($name){
$query = sprintf("INSERT INTO users(name,email,number,password,city,town) VALUES('%s','%s','%s','%s','%s','%s');",mysqli_real_escape_string($conn,$name),mysqli_real_escape_string($conn,$email),mysqli_real_escape_string($conn,$number),mysqli_real_escape_string($conn,$password),mysqli_real_escape_string($conn,$city),mysqli_real_escape_string($conn,$town));
$result = mysqli_query($conn,$query);
if($result){
	$id = mysqli_insert_id($conn);
	$_SESSION['id'] = $id;
	$_SESSION['contact'] = $number;
	header("location:profile.php");
}
}else{
	header("location:error.php?from=signup.php&error=Empty form field(Name)");
}
?>