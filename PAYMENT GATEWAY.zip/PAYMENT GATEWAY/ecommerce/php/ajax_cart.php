<?php
require "all_functions.php";
$id = $_REQUEST['id'];
$quantity = $_REQUEST['quantity'];
$_SESSION['cart'][$id] =  $quantity;
?>