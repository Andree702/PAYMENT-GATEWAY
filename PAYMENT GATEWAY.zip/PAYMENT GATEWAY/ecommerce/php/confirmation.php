<?php
require "all_functions.php";
$total = $_SESSION['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Confirmation</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/fixed.css">
	<link rel="stylesheet" type="text/css" href="../css/checkout.css">
	<script src="../js/jquery.js"></script>
	<style>
		body * {
			font-family: sans-serif;
		}
		
		article{
			background: hsl(0,0%,95%);
			min-height: 300px;
			box-sizing: border-box;
			padding: 20px;
		}
		h1{
			font-size: 23px;
			margin-top: 40px;
		}
		p a{
			color: hsl(210,100%,50%);
		}
		@media(min-width: 1000px){
article{
	width: 50%;
	background: white;
	margin: auto;
	padding: 20px;
	box-sizing: border-box;
	margin-top: 30px;
}
		}
	</style>
</head>
<body>
	<header>
<?php
navigations($home = false, $top = true);
?>
</header>
	<article>
<?php
$name = htmlentities($_REQUEST['name']);
echo "<h1>Dear $name, Thank you for purchasing from us.</h1>";
echo "<p>Order received, please follow the link bellow to make payment</p>";
echo "<p><a href='../../payment_api/payment_interface.php?id=15&amount=$total'>Make payment</a></p>";
?>
</article>
<footer>
	<?php
navigations($home = false, $top = false);
?>
</footer>
</body>
<script>
	var home = false;
</script>
<script src='../js/all.js'></script>

</body>
</html>
