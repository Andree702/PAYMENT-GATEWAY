<?php
session_start();
error_reporting(0);
if(!$_SESSION['admin']){
	header("location:../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Add product</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms1.css">
	<script src="../js/jquery.js"></script>
	<style>
		.msg{
			position: absolute;
			width: 80%;
			left:10%;
			right: 10%;
			text-align: center;
			border-radius: 20px;
			background: black;
			padding:20px;
			color: white;
			margin: auto;

		}
	</style>
</head>
<body>
	<?php
if($_REQUEST['success']){
	echo "<p class='msg'>".$_REQUEST['success']."</p>";
}
?>
	<p class="p"><a href="admin.php">Back to admin pannel</a></p>
	<article>
<form action="process_add.php" method="post" enctype="multipart/form-data">
<ul>
	<li>
		<label class="name1">Product Name</label>
		<input type="text" name="product" required class="name_g">
	</li>
	<li>
		<label>Price</label>
		<input type="text" name="price" required>
	</li>
	<li>
		<label class="lab">Wholesale/retail</label>
		<select name="type" class="type" required>
			<option value="Retail">Retail</option>
			<option value="Wholesale">Wholesale</option>
		</select>
	</li>
	<li>
		<label class="lab">Category</label>
		<select name="category" class="category" required>
			<option value="">Select type</option>
			<option value="Men shoes">Men shoes</option>
			<option value="Men shirts">Men shirts</option>
			<option value="Other products">Other products</option>
		</select>
	</li>

<li>

<label class="lab">Sub-categories</label>
		<select name="sub" class="sub Shoes1" required>
			<option value="All shoes">All shoes</option>

		</select>

		<select name="sub" class="sub Shoes2" required>
			<option value="All short">All shirts</option>
		</select>

		<!--<select name="sub" class="sub Shoes6" required>
			<option value="Mouse">Mouse</option>
			<option value="Batteries">Batteries</option>
			<option value="USB">USB</option>
			<option value="Keyboard">Keyboard</option>
			<option value="Display">Display</option>
			<option value="Sound systems">Sound systems</option>
			<option value="Other computer accessories">Other PC accessories</option>
		</select>

		<select name="sub" class="sub Shoes7" required>
                <option value="Game pads">Game pads</option>
                <option value="Game Console">Game Consoles</option>
                <option value="Gaming laptops">Gaming laptops</option>
		</select>
		<select name="sub" class="sub Shoes8" required>
                <option value="Discounted">Discounted</option>
		</select>-->
	</li>
<li>
	<label>Brand name</label>
	<input type="text" name="brand">
</li>
	<li>
		<label class="lab">Colours</label>
		<textarea name="colours" placeholder="Example: red, green and blue"></textarea>
	</li>
	<li>
		<label class="lab">Sizes</label>
		<textarea name="sizes" placeholder="Example: small, medium and large or any meaningful description of available sizes"></textarea>
	</li>

	<li>
		<label class="text">Description</label>
		<textarea name="description" required placeholder="Description"></textarea>
	</li>
	<li>
		<label for="avatar">Images(2)</label>
		<input type="hidden" name="MAX_FILE_SIZE" value="5000000">
		<input type="file" name="avatar[]" multiple id="avatar" onchange="change();" required>
		<p class="images"></p>
	</li>
	<input type="submit" value="Add product">
	<img src="">
</ul>	
</form>
</article>
<script>
	$(document).ready(function(){
    $('.category').change(function(){
    var sub = $(this).val();
    $(".sub").each(function(){
    $(this).hide().attr('disabled',true);
    })//end model
    //Categories and sub-categories relationships
    if(sub == 'Men shoes'){
       sub = 'Shoes1';
    }else if(sub == 'Men shirts'){
        sub = 'Shoes2';
    }else if(sub == 'Grooming'){
    	 sub = 'Shoes3';
    }else if(sub == 'Kennels'){
    	sub = 'Shoes4';
    }else if(sub == 'Other products'){
    	sub = 'Shoes5';
    }

    $(".sub").hide().attr('disabled',true);
    $('.'+sub+'').css('display','block').attr('disabled',false);
    })//end brand

    $(".name_g").blur(function(){
var name_group = $(this).val();
var name = 'name='+ name_group;//imported code with less semantic
$.post('exist_name.php',name,function(data){
if(data == 'yes'){
    $('.name1').text('You have posted this already').css('color','red').fadeOut().fadeIn();
}else{
$('.name1').text('Product name').css('color','grey');
}
})//end post
})//end blur
	})//end ready
	function change(){
		$('.images').text('');
		for(var a = 0; a < 2;a++){
			$('.images').append('<img src="'+URL.createObjectURL(event.target.files[a])+'">');
		}
	}
	 $(".msg").fadeOut().fadeIn().fadeOut(5000);
</script>
</body>
</html>