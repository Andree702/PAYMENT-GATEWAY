<?php
require "all_functions.php";
if(!$_SESSION['admin']){
	header("location:../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<script src="../js/jquery.js"></script>
	<style>
	body{
		font-family: helvetica,sans-serif;
	}
		div h2{
			font-weight: normal;
			color: grey;
			font-size: 15px;
		}
		div{
			background: hsl(0,0%,98%);
			padding:5px;
			margin-bottom: 10px;
		}
		h4{
			margin-top: 120px;
		}
		h3 a{
			color: red;
		}
		.verified{
			color: blue;
			margin-top: -10px;
			font-weight: bold;
			font-size: 14px;
			background: hsl(210,100%,95%);
			text-decoration: none;
			padding: 3px;
			border-radius: 3px;
			margin-bottom: 15px;
			display: block;
			width: 150px;
			text-align: center;
		}
		.msg{
			position: absolute;
			width: 80%;
			left:10%;
			right: 10%;
			text-align: center;
			border-radius: 20px;
			background: black;
			padding:20px;
			color: white;
			margin: auto;

		}
		header{
			position: fixed;
			text-align: center;
			padding: 10px;
			top: 0;
			left: 0;
			right: 0;
			padding-top: 30px;
			background: white;
		}
		header ul{
			padding: 0px;
			margin: 0px;
			text-align: center;
		}
		header li{
			list-style: none;
			display: inline-block;
			text-align: center;
			color: white;
		}
		header a{
			box-sizing: border-box;
		text-align: center;
			color: black;
			display: block;
			border-radius: 3px;
			display: block;
			vertical-align: middle;
			border-radius: 50%;
			box-shadow: 2px 2px 5px silver;
			width: 60px;
			padding-top: 13px;
			height: 60px;
			text-decoration: none;
		}
		header a:hover{
			background: hsl(0,0%,90%);
		}
		header a img:hover{
			transform: scale(1.2);
		}
	</style>
</head>
<body>
<header>
	<ul>
		<li><a href="add.php"><img src="../img/post.jpg"></a></li>
		<li><a href="admin_search.php"><img src="../img/search2.png"></a></li>
		<li><a href="admin_logout.php"><img src="../img/log.png"></a></li>
	</ul>
</header>
<?php
if($_REQUEST['success']){
	echo "<p class='msg'>".$_REQUEST['success']."</p>";
}
$count = 1;
$query = sprintf("SELECT * FROM products,orders WHERE orders.product_id= products.id ORDER BY orders.order_id;");
$result = mysqli_query($conn,$query);
if(mysqli_num_rows($result) !=0){
	echo "<h4>Orders</h4>";
	while($row = mysqli_fetch_array($result)){
	$name = htmlentities($row['name']);
	$number = htmlentities($row['number']);
	/*$city =htmlentities($row['city']);
	$town = htmlentities($row['town']);*/
	$location = htmlentities($row['location']);
	$bus = htmlentities($row['bus']);
	$product_id = $row['product_id'];
	$quantity = $row['quantity'];
	$sizes = $row['sizes'];
	if(!$sizes){
		$sizes = 'default';
	}
	$colours = $row['colours'];
	if(!$colours){
		$colours =' default';
	}
	$date = $row['date'];
	$product = htmlentities($row['product']);
	$user_id = $row['user_id'];
	if($user_id){
		$query_user = sprintf("SELECT * FROM users WHERE id = %d;",$user_id);
		$result_user = mysqli_query($conn,$query_user);
		if($result_user){
			$row_user = mysqli_fetch_array($result_user);
			$name = $row_user['name'];
			$location = $row_user['city'];
			$bus = $row_user['town'];
			$number = $row_user['number'];
		}
	}
	$id = $row['order_id'];
	echo "<div>( $count )
	<h2>$name , $number , $location- $bus ,<br>Product : $product , Quantity : $quantity, Details : $sizes,  Date : $date</h2>
	<h3><a href='delete_order.php?id=$id' class='del'>Delete</a></h3>";
	
	echo "</div>";
	//if verified write a code to delete verified orders
	$count ++;
}
}
?>
<section id="history">
	
</section>
<script>
	$(document).ready(function(){
       $(".del").click(function(evt){
      var con = confirm("Do you really want to delet this?");
      if(!con){
      	evt.preventDefault();
      }
     })//edn click
     $(".msg").fadeOut().fadeIn().fadeOut(5000);
	})//end ready
</script>
</body>
</html>