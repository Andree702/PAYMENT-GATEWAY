<?php
session_start();
if(!$_SESSION['admin']){
	header("location:../index.php");
}
unset($_SESSION['admin']);
header("location:admin_auth.php");
?>