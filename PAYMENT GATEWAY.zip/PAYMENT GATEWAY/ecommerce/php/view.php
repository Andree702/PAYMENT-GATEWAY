<?php
require "all_functions.php";
$total_items = count($_SESSION['cart']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>View</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta name="theme-color" content="<?php echo $theme; ?>">
	<link rel="stylesheet" type="text/css" href="../css/fixed.css">
	<link rel="stylesheet" type="text/css" href="../css/view.css">
	<script src="../js/jquery.js"></script>
	<script src="../js/jquery.rateyo.js"></script>
	<style>
	</style>
</head>
<body>
<header>
<?php
navigations($home = false, $top = true);
?>
</header>
<?php
$id = $_REQUEST['id'];
$query = sprintf("SELECT * FROM products WHERE id = %d;",mysqli_real_escape_string($conn,$id));
$result = mysqli_query($conn,$query);

if(mysqli_num_rows($result)!= 0){
	$row = mysqli_fetch_array($result);
	$product = htmlentities($row['product']);
	$price = $row['price'];
    $brand = htmlentities($row['brand']);
    $category = htmlentities($row['categories']);
    $colours = htmlentities($row['colours']);
    if(!$colours){
    	$colours = 'Default';
    }
    $sizes = htmlentities($row['sizes']);
    if(!$sizes){
    	$sizes = 'Default';
    }
	$desc = htmlentities($row['description']);
	$img1 = htmlentities($row['img1']);
	$img2 = htmlentities($row['img2']);
}
echo "<section>
<nav><span><img src='$img1'></span>";
if($img2){
echo "<span><img src='$img2'></span>";
}
echo "</nav><div>
<img src='$img1'>
</div></section><article>";


echo "<table>
<h3 class='spec'>Specification</h3>
<tr><td>Name </td><td>$product</td></tr>
<tr><td>Price</td><td> $price</td></tr>
<tr><td>Type</td><td>$category</td></tr>";
if($brand){
echo "<tr><td>Brand </td><td>$brand</td></tr>";
}
if($sizes){
echo "<tr><td>Sizes </td><td> $sizes</td></tr>";
}
if($colours){
echo "<tr><td>Colours </td><td> $colours</td></tr>";
}
echo "</table>
<span>";

echo "<em class='add_to_cart' id='$id'>Add to cart</em>";

echo "<h3>Description</h3>
<p class='desc'>$desc</p>
</article><aside>";
$query_suggest = sprintf("SELECT * FROM products WHERE categories='%s' LIMIT 5;",$category);
$result_suggest = mysqli_query($conn,$query_suggest);
if(mysqli_num_rows($result_suggest) > 1){
	echo "<h3>Suggested for you</h3>";
while($row_suggest = mysqli_fetch_array($result_suggest)){	
	$products1 = $row_suggest['product'];
	$pro1 = $products1;
		if(strlen($products1) > 15){
		$products1 = substr($products1, 0,10).'...';
	}
		$price1 = $row_suggest['price'];
		$id1 = $row_suggest['id'];
		if($id1 == $id){
			continue;
		}
		$img1 = $row_suggest['img1'];
		
		echo "<a href='view.php?id=$id1' class='products'>
           <img src='$img1'>
           <br><b>$products1</b><br>
           <em>GHS $price1</em><br>
           <em class='add_to_cart' id='$id1'>Add to cart</em></a>";
}
}
?>
</aside>

<footer>
	<?php
    navigations($home = false, $top = false);
	?>
</footer>
<script>
	var home = false;
</script>
<script src="../js/all.js"></script>
<script>
	$(document).ready(function(){
    
    $("section div img").hover(function(){
         var src = $(this).attr('src');
         $("section").append("<img src="+src+" class='huge_img'>");
    },function(){
      $(".huge_img").remove();
    })//end hover
 $(" section span img").click(function(){
   var link = $(this).attr('src');
   link = encodeURI(link);
   $('section div img').attr('src',link);
   })//end click

	})//end ready
</script>
</body>
</html>