<?php
require "all_functions.php";
if(!$_SESSION['admin']){
	header("location:../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Search</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms1.css">
	<script src="../js/jquery.js"></script>
	<style>
		.cant,.del{
			text-align: center;
			margin-top: 30px;
			color: red;
		   display: block;
		}
	</style>
</head>
<body>
<?php
if($_REQUEST['search']){
	$search_word = mysqli_real_escape_string($conn,$_REQUEST['search']);
	$query = sprintf('SELECT * FROM products WHERE product LIKE "%s";',"%".$search_word."%");
	$result = mysqli_query($conn,$query);
	if(mysqli_num_rows($result) != 0){
		$row = mysqli_fetch_array($result);
		$product  = htmlentities($row['product']);
		$price = htmlentities($row['price']);
		$sizes = htmlentities($row['sizes']);
		$colors = htmlentities($row['colours']);
		$description = htmlentities($row['description']);
		$id = $row['id'];
		echo "<div>
		<p>$product</p>
		<p><a href='delete.php?id=$id' class='del'>Delete</a></p>
		
         <form method='post' action='edditor.php?id=$id&name1=$product' class='edditor'>
         <ul>
         <li>
        <label>Initial name- $product</label>
        <input type='text' name='name'>
        </li>
        <li>
        <label>Initial price- $price</label>
        <input type='text' name='price'>
        </li>
        <li>
        <label>Initial colors- $colors</label>
        <input type='text' name='colors'>
        </li>
        <li>
        <label>Initial sizes- $sizes</label>
        <input type='text' name='sizes'>
        </l>
        <li>
        <label>Initial description</label>
        <textarea name='description'>$description</textarea>
        </li>
        <li>
        <input type='submit' value='Change'>
        </li>

</ul>
         </form>
		</div>";
	}else{
	echo "<p class='cant'>Searched product can not be found</p>";
}
}
?>
<p class="p"><a href="admin.php">Back to admin pannel</a></p>
<form action="admin_search.php" method="post">
<ul>
	<li>
		<label>Search products</label>
		<input type="search" name="search">
	</li>
	<li>
		<input type="submit" value="search">
	</li>
</ul>	
</form>
<script>
	$(document).ready(function(){
     $(".del").click(function(evt){
      var con = confirm("Do you really want to delet this?");
      if(!con){
      	evt.preventDefault();
      }
     })//edn click
	})//end ready
</script>
</body>
</html>