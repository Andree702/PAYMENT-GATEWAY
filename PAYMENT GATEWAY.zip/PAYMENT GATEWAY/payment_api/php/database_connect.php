<?php
$conn = mysqli_connect(HOST,USER,PASSWORD) or header("location:error.php?error=Error connecting to our database server, please try again later&from=../index.php");
mysqli_select_db($conn,DATABASE) or header("location:error.php?error=Error connecting to our database server, please try again later&from=../index.php");
?>