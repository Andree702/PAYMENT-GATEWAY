<?php
require "all_functions.php";
if(!isset($_SESSION['admin'])){
	if(isset($_POST['password'])){
		trim($password = $_POST['password']);
		$query = sprintf("SELECT * FROM bank WHERE pass = '%s';",mysqli_real_escape_string($conn,$password));
		$result = mysqli_query($conn,$query);
		if(mysqli_num_rows($result) != 0){
        $row = mysqli_fetch_array($result);
        $pass  = $row['pass'];
        $_SESSION['admin'] = $pass;
        header("location:admin.php");
		}else{
			$erro  = 'Incorrect password';
		}
	}

}else{
	header("location:admin.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<style>
	h1 img{
		vertical-align: middle;
		width: 140px;
		margin-right: -30px;
	}
	h1{
		color: white;
	}
		.error{
			text-align: center;
			margin-top: 10px;
			margin-bottom: -10px;
			font-size: 14px;
			color: red;
			font-family: sans-serif;
		}
		input[type='password']{
			padding-left: 5px;
			background-color: white;
		}
		h1{
			text-align: center;
			font-style: italic;
			margin-top: 30px;
			font-size: 30px;
			margin-bottom: 10px;
		}
		h1 img{
			width: 100px;
			margin-left: -30px;
		}
		form{
			text-align: center;
			padding-top: 20px;
			margin-bottom: 50px;
		}
		form *{
			list-style: none;
			margin-left: 0px;
			box-sizing: border-box;
			padding: 0px;
			margin: 0px;
		}
		input{
			width: 240px;
			height: 40px;
			margin-bottom: 5px;
			border:none;
			border-radius: 20px;
		}
		input[type='password']{
			background: hsl(0,0%,80%);
		}
		input[type='submit']{
			background: black;
			color: white;
		}
		body{
		 background: hsl(50,100%,50%);
		 padding:0px;
		 margin: 0px;
		}
		article {
			box-sizing: border-box;
			padding: 10px;
			background: white;
		}
		@media(min-width: 1000px){

			article{
				width: 50%;
				margin: auto;
				padding: 30px;
				margin-top: 130px;
				border-radius: 10px;
				vertical-align: middle;
				background: hsla(0,0%,100%,0.9);
			}

		}
	</style>
</head>
<body>
	<article>
	<h1><img src="../img/logo.png"></h1>
	<?php
	if($erro){
	echo "<p class='error'>$erro</p>";
	}
	?>
	
<form method="post" action="admin_auth.php">
	<ul>
		<li>
	<input type="password" name="password" placeholder="password">
	</li>
	<li>
	<input type="submit" value="Log in">
	</li>
	</ul>
</form>
</article>
</body>
</html>