<?php
session_start();
if(!$_SESSION['admin']){
header("location:admin_auth.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="../css/bank.css">
    <script src="../js/jquery.js"></script>
    <style>
    </style>
</head>
<b class="menu">Menu</b>
<body>
  <!-- The section below is for the showing notification-->
  <section></section>
<aside>
  <ul>
    <li>
      <a href="logout.php"><img src="../img/logout.png">Logout</a>
    </li>
    <li>
      <a href="#" class="tr"><img src="../img/history.png">Transactions</a><!-- add refund functionalities at the end of transactions -->
    </li>
    <li>
      <a href="#" class="ac"><img src="../img/user.png">Account/pay</a>
    </li>
    <li>
      <a href="#" class="cm"><img src="../img/customer.png">Customers API</a>
    </li>
  </ul>
</aside>
<article class="account">
  <div>
  <h1>
    Make payment
  </h1>
  <form class="change">
    <ul>
      <li>
        <input type="search" class="search_account" name="account_number" placeholder="Enter account number"><br><br><b class="search">Search</b>
      </li>
   
      <li>
        <input type="text" name="first_name" class="first" placeholder="First name">
      </li>
      <li>
        <input type="text" name="first_name" class="last" placeholder="Last name">
      </li>

      <li>
        <label>Account balance</label>
        <input type="text" name="balance" class="balance">
      </li>

      <li>
        <label>Secret pin</label>
        <input type="text" name="pin" class="pin">
      </li>
      <li>
       
        <input type="number" name="amount" class="amount" placeholder="Enter amount" required>
      </li>
      <li>
        <input type="submit" value="Debit / Pay">
      </li>
    </ul>
  </form>
</div>

  <div>
  <h1>
    Create account
  </h1>
  <form class="create">
    <ul>
      <li>
        <input type="text" name="first" class="first" placeholder="First name" required="">
      </li>
      <li>
        
        <input type="text" name="last" class="last" placeholder="Last name" required="">
      </li>
      <li>
        <input type="email" name="email" class="email" placeholder="email" required="">
      </li>
      <li>
        <input type="text" name="number" class="number" placeholder="Telephone number" required="">
      </li>
      <li>
        <input type="text" name="address" class="address" placeholder="address" required="">
      </li>
      <li>
        <input type="text" name="id" class="id" placeholder="ID" required="">
      </li>
      <li>
        <input type="submit" value="Create">
      </li>
    </ul>
  </form>
</div>
</article>

<article class="history">
  <table>
      
  </table>
</article>

<article class="customer">

  <div class="customer_f">
     <h1>Add customer</h1>
  <form class="customer_form">
    <ul>
      <li>
        <input type="text" name="customer_name" class="customer_name" placeholder="Customer, eg. Jumia" required="">
      </li>
      <li>
        <input type="text" name="account_number" class="account_number" placeholder="Account number" required="">
      </li>
      <li>
        <input type="submit" value="Add customer">
      </li>
    </ul>
  </form>
</div>
<div class="customer_api">
  <h1>Customers API</h1>
</div>
</article>


<script src="../js/account.js"></script>
<script src="../js/customer_api.js"></script>
<script src="../js/history_data.js"></script>

<script>
$(document).ready(function(){
  //slideTogle aside, for mobile app
  $(".menu").click(function(evt){
  $("aside").slideToggle();
  })//end click


  //hide all the various sections apprt from the account
$(".transactions, .history,section,.customer").hide();
//Bellow event handlers are used to show or hide the other sections of admin interface
//account creation and payment
$("aside").on('click','.ac',function(evt){
$("li a").removeClass('active');
$(this).addClass('active');
evt.preventDefault();
$("article").hide();// hide other sections
$(".account").show();//show the transaction section
})

//the customer api section
$("body").on('click','.cm',function(evt){
  $("li a").removeClass('active');
$(this).addClass('active');
evt.preventDefault();
  $("section").show().text("Loading customer's API data..");
$("article").hide();// hide other sections
$(".customer").show();//show the transaction section
fetchCustomerApi();
})


//the history api section
$("body").on('click','.tr',function(evt){
  $("li a").removeClass('active');
$(this).addClass('active');
$("section").show().text("Loading transaction history...");
evt.preventDefault();
$("article").hide();// hide other sections
$(".history").show();//show the transaction section
showHistory();
})
})//end ready
</script>
</body>
</html>