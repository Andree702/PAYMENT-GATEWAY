<?php
require "all_functions.php";
//header("Content-type: application/json; charset=utf-8");
//grab data in json format, decode and save them
//this file also save the date a user joined
//upon successfully saving the user data send a succes message to the callback function in the jax javascript
//Header authentication

if(!(isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW']))){
	header("WWW-Authenticate: Basic realm='Restricted Area'");
	header("HTTP/1.0 401 Unauthorized");
	echo "This page is ristricted";
	die();
}else{
	$user = $_SERVER['PHP_AUTH_USER'];
	$password = $_SERVER['PHP_AUTH_PW'];
    if($user != 'gcb' || $password != '123'){
    	echo "Incorrect user name or password";
    	die();
    }
}

//json_decode(file_get_contents("php://input"));

$operation = $_REQUEST['operation'];

if($operation == 'create'){

$first_name = $_REQUEST['first_name'];
$last_name = $_REQUEST['last_name'];
$email = $_REQUEST['email'];
$number = $_REQUEST['number'];
$id = $_REQUEST['id'];
$address = $_REQUEST['address'];
$account = time();
$secret1 = rand();
$secret = crypt($secret1,$email);
$account = substr($account.$secret1, 0,13);
$date = date("Y-m-d h:i:s");

$query_save = sprintf("INSERT INTO users(first_name,last_name,email,number,address,id_number,balance,account_number,date_joined,secret) VALUES('%s','%s','%s','%s','%s','%s',%f,'%s','%s','%s');",mysqli_real_escape_string($conn,$first_name),mysqli_real_escape_string($conn,$last_name),mysqli_real_escape_string($conn,$email),mysqli_real_escape_string($conn,$number),mysqli_real_escape_string($conn,$address),mysqli_real_escape_string($conn,$id),0,mysqli_real_escape_string($conn,$account),mysqli_real_escape_string($conn,$date),mysqli_real_escape_string($conn,$secret));

$result_save = mysqli_query($conn,$query_save);

if($result_save){
	echo "Acccount created successfully with account_number $account";
}else{
	echo mysqli_error($conn);
}
}elseif($operation == 'search'){
	//carry the account 
	$account = $_REQUEST['account'];

	$query_search = sprintf("SELECT * FROM users WHERE account_number = '%s';",$account);
	$result_search = mysqli_query($conn,$query_search);

	if($result_search){
		while($row = $result_search->fetch_assoc()) {	
		$item = $row;	
		}
		
		$data = json_encode($item,JSON_NUMERIC_CHECK);
		echo $data;
	}

}elseif($operation == 'pay'){
//do the incrementation of payment here,save in history
//to-do, consider add a boolean or options to either create money or deduct from the main bank account balance
$account_number = $_REQUEST['account'];
$balance = $_REQUEST['balance'];

$query_new_balance = sprintf("SELECT balance FROM users WHERE account_number = '%s';",$account_number);
$result_old_balance = mysqli_query($conn,$query_new_balance);
$row_balance = mysqli_fetch_array($result_old_balance);
$old_balance =  $row_balance['balance'];

$total_balance = $balance + $old_balance;
$date = date("Y-m-d h:i:s");

$query_pay = sprintf("UPDATE users SET balance = %f WHERE account_number = '%s';",$total_balance,$account_number);
$result_pay = mysqli_query($conn,$query_pay);
// save this transaction in history
$query_history = sprintf("INSERT INTO history(amount,date_paid,send_to,sender,customer,email) VALUES(%f,'%s','%s','%s','%s','%s');",mysqli_real_escape_string($conn,$balance),mysqli_real_escape_string($conn,$date),mysqli_real_escape_string($conn,$account_number),mysqli_real_escape_string($conn,'gcb'),mysqli_real_escape_string($conn,$account_number),mysqli_real_escape_string($conn,'gcb@gmail.com'));

echo $total_balance;

   		$result_history = mysqli_query($conn,$query_history);
}elseif($operation == 'balance'){
	$query_balance = sprintf("SELECT balance FROM bank");
	$result_balance = mysqli_query($conn,$query_balance);
	if($result_balance){
		$row = mysqli_fetch_array($result_balance);
		$balance = $row['balance'];
		echo $balance;
	}
}elseif($operation == 'customer_api'){
	$customer_name = $_REQUEST['customer'];
	$bank_account = $_REQUEST['bank_account'];

	$query_customer = sprintf("INSERT INTO customer_api(bank_account,customer_name) VALUES('%s','%s');",mysqli_real_escape_string($conn,$bank_account),mysqli_real_escape_string($conn,$customer_name));
	$result_customer = mysqli_query($conn,$query_customer);

	if($result_customer){
		echo "Customer added";//remove this section and perform this asynchronously;
	}else{
		echo "Error occured saving customer details";
	}
}elseif($operation == 'fetchCustomerApi'){

		$query_api = "SELECT * FROM customer_api";
		$result_api = mysqli_query($conn,$query_api);
		if($result_api){
		while($row[] = $result_api->fetch_assoc()) {	
		$item = $row;	
		}
		
		$data = json_encode($item,JSON_NUMERIC_CHECK);
		echo $data;
		}
	
}elseif($operation == 'history'){

		$query_history = "SELECT * FROM history";
		$result_history = mysqli_query($conn,$query_history);
		if($result_history){
		while($row[] = $result_history->fetch_assoc()) {	
		$item = $row;	
		}
		
		$data = json_encode($item,JSON_NUMERIC_CHECK);
		echo $data;
		}
	
}elseif($operation == 'refund'){
	$history_id = $_REQUEST['id'];

	//fetch details of the history
	$query =sprintf("SELECT * FROM history WHERE history_id = %d;",$history_id);
	$result = mysqli_query($conn,$query);
	if($result){
		$row = mysqli_fetch_array($result);
		$amount = $row['amount'];
		$sender = $row['sender'];//increment sender account, sender drops the sender account
		$receiver = $row['send_to'];
		$customer = $row['customer'];
	}

	//deduct from the receiver balance
   $query_receiver_balance = sprintf("SELECT balance FROM users WHERE account_number = '%s';",mysqli_real_escape_string($conn,$receiver));
   $result_receiver_balance = mysqli_query($conn,$query_receiver_balance);
   $row_receiver_balance = mysqli_fetch_array($result_receiver_balance);
   $balance = $row_receiver_balance['balance'];
   $new_balance = $balance - $amount;

   $query_update  = sprintf("UPDATE users SET balance = %f WHERE account_number = '%s';",mysqli_real_escape_string($conn,$new_balance),mysqli_real_escape_string($conn,$receiver));
   	$result_update1 = mysqli_query($conn,$query_update);
    

	//do the increment if customer is not User
	if($customer != 'User'){
	$query_sender_balance = sprintf("SELECT balance FROM users WHERE account_number = '%s';",mysqli_real_escape_string($conn,$sender));
   $result_sender_balance = mysqli_query($conn,$query_sender_balance);
   $row_sender_balance = mysqli_fetch_array($result_sender_balance);
   $balance = $row_sender_balance['balance'];
   $new_balance = $balance + $amount;
  

    $query_update  = sprintf("UPDATE users SET balance = %f WHERE account_number = '%s';",mysqli_real_escape_string($conn,$new_balance),mysqli_real_escape_string($conn,$sender));
   	$result_update = mysqli_query($conn,$query_update);
}
   	if($result_update1){
   		//delete the history
   		$query_delete_history = sprintf("DELETE FROM history WHERE history_id = %d;",$history_id);
   		$result_delete = mysqli_query($conn,$query_delete_history);
   		
   		echo "Refunded";
   	}

}
?>