<?php
error_reporting(0);
session_start();
require 'config.php';
require 'database_connect.php';
?>