<?php
require "php/all_functions.php";
	//from web interface, check if account really exist, there is enough money,the api id sent is exist

//basic authentication for payment processor
if(!(isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW']))){
	header("WWW-Authenticate: Basic realm='Restricted Area'");
	header("HTTP/1.0 401 Unauthorized");
	echo "This page is ristricted";
	die();
}else{
	$user = $_SERVER['PHP_AUTH_USER'];
	$password = $_SERVER['PHP_AUTH_PW'];
    if($user != 'gcb' || $password != '123'){
    	echo "Incorrect user name or password";
    	die();
    }
}
	$customer_id = $_REQUEST['id'];
	$account_number = $_REQUEST['account_number'];
	$email = $_REQUEST['email'];
	$amount = $_REQUEST['amount'];//to-do  find a way ro make this useful
	$secret = trim($_REQUEST['secret']);
	$date_paid = date("Y-m-d h:i:s");

	//check for customer id
mysqli_autocommit($conn,false);
	$query_user = sprintf("SELECT * FROM users WHERE account_number ='%s' AND secret='%s';",mysqli_real_escape_string($conn,$account_number),mysqli_real_escape_string($conn,$secret));
	$result_user = mysqli_query($conn,$query_user);
	$row_name =  mysqli_fetch_array($result_user);
	$name =  $row_name['first_name'];

	if(mysqli_num_rows($result_user) == 0){
		echo "Incorrect account number or secret pin";
		die();
	}

	//check for account balance if it is enough to pay for this item

	$query_balance = sprintf("SELECT balance FROM users WHERE account_number = '%s';",mysqli_real_escape_string($conn,$account_number));
	$result_balance = mysqli_query($conn,$query_balance);

	if($result_balance){
		$row = mysqli_fetch_array($result_balance);
		$balance = $row['balance'];
		 if($balance < $amount){
		 	echo "Insufficient balance, please top up. Your current balance is $balance";
		 	die();
		 }else{
		 	$new_balance = $balance - $amount;
		 	//update the user balance

		 	$query_new_balance = sprintf("UPDATE users SET balance = %f WHERE account_number='%s';",mysqli_real_escape_string($conn,$new_balance),mysqli_real_escape_string($conn,$account_number));
		 	$result_new_balance = mysqli_query($conn,$query_new_balance);
		 	//try using inno DB and commit to do these stuffs
		 }
	}else{
		echo "An error occured, please try again later";
	}

//retrieving customer bank account

$query_account = sprintf("SELECT * FROM customer_api WHERE customer_id=%d",mysqli_real_escape_string($conn,$customer_id));
$result_account = mysqli_query($conn,$query_account);
if($result_account){
	$row_account = mysqli_fetch_array($result_account);
	$customer_bank_account = $row_account['bank_account'];
	$customer_name = $row_account['customer_name'];
	//retrive the current balance in the customer balance

	$query_customer_balance = sprintf("SELECT balance FROM users WHERE account_number = '%s';",mysqli_real_escape_string($conn,$customer_bank_account));
   $result_customer_balance = mysqli_query($conn,$query_customer_balance);
   if($result_customer_balance){
   	$row_customer_balance = mysqli_fetch_array($result_customer_balance);
   	$current_customer_balance = $row_customer_balance['balance'];
   	$new_customer_balance = $current_customer_balance +  $amount;

   	//update the balance of the customer
   	$query_update  = sprintf("UPDATE users SET balance = %f WHERE account_number = '%s';",mysqli_real_escape_string($conn,$new_customer_balance),mysqli_real_escape_string($conn,$customer_bank_account));
   	$result_update = mysqli_query($conn,$query_update);
   	if($result_update){
   		//put this transaction in the history books
   		//to-do add the email of the sender here
   		$query_history = sprintf("INSERT INTO history(amount,date_paid,send_to,sender,customer,email) VALUES(%f,'%s','%s','%s','%s','%s');",mysqli_real_escape_string($conn,$amount),mysqli_real_escape_string($conn,$date_paid),mysqli_real_escape_string($conn,$customer_bank_account),mysqli_real_escape_string($conn,$account_number),mysqli_real_escape_string($conn,$customer_name),mysqli_real_escape_string($conn,$email));
   		$result_history = mysqli_query($conn,$query_history);
   	}
   }	
}

//After payment is completed, send payment succeful to the payment UI
if($result_new_balance && $result_update){
mysqli_commit($conn);
echo "Dear $name, payment has been made succesful, your new balance is $new_balance. Thank you.";
}else{
mysqli_rollback($conn);
echo "An error occured please try again later";
}
?>