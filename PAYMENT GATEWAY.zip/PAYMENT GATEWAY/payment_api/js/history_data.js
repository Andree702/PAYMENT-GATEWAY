//functionalitrieving history
function showHistory(){
	var query = 'operation=history';
	$.get('api_operations.php',query,function(data){
     var convertedData = JSON.parse(data);
     $(".history table").html('');
     for(var list in convertedData){
     $(".history table").append("<tr><td>Date: "
     	+convertedData[list]['date_paid']
     	+"</td><td>Amount: "
     	+convertedData[list]['amount']
     	+"</td><td>Paid to: "
     	+convertedData[list]['customer']
     	+"</td><td>Email: "
     	+convertedData[list]['email']
     	+"</td><td class='refund'><a href='#' class='a' id='"
     	+convertedData[list]['history_id']
     	+"'>Refund</a></td></tr>");
     }
    $("section").hide();
	});
}
//Refund functionality
$("table").on('click','a',function(evt){
$("section").show().text("Refunding...");
var id  = $(this).attr('id');
var con  = confirm("Do you really want to refund?");
if(con){
     
var query = 'operation=refund&id='+id;
	$.get('api_operations.php',query,function(data){
 alert(data);
 showHistory();
 $("section").hide();
	});
}
})//