//functionality for grabbing the users informartion for the creation of account
/*
\Grab put the functionalities in a function

*/
$(".create").submit(function(evt){
  $("section").show().text("Creating an account...");
  evt.preventDefault();//prevent the default behaviour of the form, thus not submiting, but rather use javascript to grab the data and send them asynchronously

    var first_name = $(".create .first").val();
    var last_name = $(".create .last").val();
    var email = $(".create .email").val();
    var address = $(".create .address").val();
    var id = $(".create .id").val();
    var number = $(".create .number").val();

    var json ={//this section format the data in json to be sent to the backend with basic authentication
      'operation':'create',
      'first_name':first_name,
      'last_name': last_name,
      'email':email,
      'address':address,
      'id':id,
      'number':number,
    };

    $.ajax({
      type:'POST',
      url:'api_operations.php',
      data:json,
      success:function(data){
     alert(data);

      $(".create .first").val('');
      $(".create .last").val('');
      $(".create .email").val('');
      $(".create .address").val('');
      $(".create .id").val('');
      $(".create .number").val('');
      $("section").hide();
      }
    });

})//end create submit function





//searching for account details

$("body").on('click','.search',function(){
  $("section").show().text("Loading users data...");
var account_number = $(".search_account").val();
if(account_number){
var json ={//this section format the data in json to be sent to the backend with basic authentication
      'operation':'search',
      'account':account_number
    };

    $.ajax({
      type:'POST',
      url:'api_operations.php',
      data:json,
      /*beforeSend:function(xhr){
       xhr.setRequestHeader("Authorization", "Basic " + btoa('gcb' + ':' + '123'));
      },*/
      success:function(data){
        var obj = JSON.parse(data);
        var first_name = obj.first_name;
        var last_name = obj.last_name;
        var balance = obj.balance;
        var secret_pin = obj.secret;
        
        //feed the form fields in the .change form fields
        $(".change .first").val(first_name);
        $(".change .last").val(last_name);
        $(".change .balance").val(balance);
        $(".change .pin").val(secret_pin);
        $("section").hide();
      }
    });

}else{
  alert('please enter real account number');
}
})//end click



//Functionalities for grabbing data and paying a customer

$(".change").submit(function(evt){
  $("section").show().text("Paying a customer...");
  evt.preventDefault();
//grab only the account number and the amount to be debited, send for processing return the new amount in the account balance
var account_number = $(".change .search_account").val();
var new_balance = $(".change .amount").val();
var query = "account="+account_number+"&balance="+new_balance+"&operation=pay";
//sending via post
$.post('api_operations.php',query,function(data){
$(".change .balance").val(data);
$(".change .amount").val('');
alert("Payment made successfully");
$("section").hide();
});

})//end submit
