$(".customer_form").submit(function(evt){
    $("section").show().text("Creating customer...");
  evt.preventDefault();//prevent the default behaviour of the form, thus not submiting, but rather use javascript to grab the data and send them asynchronously

    var customer_name = $(".customer_f .customer_name").val();
    var bank_account = $(".customer_f .account_number").val();
  

    var json ={//this section format the data in json to be sent to the backend with basic authentication
      'operation':'customer_api',
      'customer':customer_name,
      'bank_account': bank_account,
    };

    $.ajax({
      type:'POST',
      url:'api_operations.php',
      data:json,
      success:function(data){
     alert(data);
     $(".customer_f .customer_name").val('');
     $(".customer_f .account_number").val('');
     fetchCustomerApi();
     $("section").hide();
      }
    });

})


function fetchCustomerApi(){
  var query = 'operation=fetchCustomerApi';
  $.get('api_operations.php',query,function(data){
   var convertedData = JSON.parse(data);
   $("div.customer_api").html('');
   for(var list in convertedData){
    var link = '../../payment_api/payment_interface.php?id='+
    convertedData[list]['customer_id']+'&amount=amount';

    $("div.customer_api").append("<span><h4>"+
      convertedData[list]['customer_name']+"</h4><span><em>"+
      link+"</em> </span></span>");
   }
   $("section").hide()
  })
}