<?php
require "php/all_functions.php";
error_reporting(0);
$customer_id = $_REQUEST['id'];
//fetching the customer's name
$query_customer = sprintf("SELECT customer_name FROM customer_api WHERE customer_id =%d;",mysqli_real_escape_string($conn,$customer_id));
$result_query = mysqli_query($conn,$query_customer);
$row = mysqli_fetch_array($result_query);
$customer_name = $row['customer_name'];

$amount = $_REQUEST['amount'];

?>
<!DOCTYPE html>
<html>
<head>
	<title>GCB pay</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<script src="js/jquery.js"></script>
	<style>
		body{
			background-color:hsl(50,100%,50%);
		}
		body *{
			font-family: helvetica,sans-serif;
		}
		form h1{
			color: black;
			font-style: italic;
			text-align: center;
		}
		form li, form ul{
			list-style: none;
			padding: 0px;
			margin: 0px;
		}
		.processing{
			color: green;
		}
		form p{
			color: white;
			font-weight: bold;
		}
		input,input[type='submit']{
			width: 280px;
			border:none;
			height: 40px;
			padding-left: 5px;
			margin-bottom: 7px;
			border-radius: 5px;
		}
		input[type='submit']{
			width: 290px;
			background-color:silver;
			font-weight: bolder;
			color: black;
		}
		form{
			text-align: center;
			padding-bottom: 100px;
			background:linear-gradient(hsl(50,100%,50%),white);
		}
		@media(min-width: 1000px){
			form{
				width: 350px;
				margin: auto;
				border-radius: 10px;
				padding: 30px;
				margin-top: 60px;
				
			}
		}
	</style>
</head>
<body>
<section></section>
<!-- the form should take the price and id as request parameter, to build the UI and for processing, consider adding the product paid for too-->
<form method="post" id="<?php echo $amount?>">
	<h1>GCB PAY</h1>
	<p id="<?php echo $customer_id?>"><?php echo "Pay GHS $amount for product purchased from $customer_name" ?></p>
	<ul>
		<li>
			<input type="email" name="email" placeholder="Email" class="email" required>
		</li>
		<li>
			<input type="text" name="account_number" placeholder="Account number" class="account_number">
		</li>
		<li>
			<input type="text" name="secret" class="secret" placeholder="Secret pin">
		</li>
		<li>
			<input type="submit" value="Pay">
		</li>
	</ul>
</form>
</body>
</html>
<script>
	//grab data from the form field, send for processing and wait for response
	$(document).ready(function(){
		//functionality for payment goes bellow
		$("form").submit(function(evt){
  evt.preventDefault();//prevent the default behaviour of the form, thus not submiting, but rather use javascript to grab the data and send them asynchronously
    $("input[type='submit']").fadeOut();
    $("form").append("<p class='processing'>Processing payment, please wait..</p>");
    var email = $(".email").val();
    var account_number = $(".account_number").val();
    var secret = $(".secret").val();
    var customer_id = $("p").attr('id');
    var amount = $(this).attr('id');


    var json ={
      'email':email,
      'account_number': account_number,
      'secret':secret,
      'id':customer_id,
      'amount': amount,
    };

//add authentication here
//and or checking the errors here http request errors
//Redirect the user to different place upon payment completion
    $.ajax({
      type:'POST',
      url:'process_payment.php',
      data:json,
      beforeSend:function(xhr){
       xhr.setRequestHeader("Authorization", "Basic " + btoa('gcb' + ':' + '123'));
      },
      success:function(data){
     alert(data);
     $("input[type='submit']").fadeIn();
     $(".processing").fadeOut();
     $(".email").val('');
     $(".account_number").val('');
     $(".secret").val('');
     //empty the form fields


      }
    });


})//end create submit function

	})
</script>