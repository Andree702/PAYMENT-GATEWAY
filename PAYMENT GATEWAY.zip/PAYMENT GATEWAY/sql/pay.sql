-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 18, 2022 at 07:29 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pay`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
CREATE TABLE IF NOT EXISTS `bank` (
  `pass` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`pass`) VALUES
('1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_api`
--

DROP TABLE IF EXISTS `customer_api`;
CREATE TABLE IF NOT EXISTS `customer_api` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_account` text DEFAULT NULL,
  `customer_name` text DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_api`
--

INSERT INTO `customer_api` (`customer_id`, `bank_account`, `customer_name`) VALUES
(14, '1652701499114', 'Andrea\'s store');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(18,6) DEFAULT NULL,
  `date_paid` text DEFAULT NULL,
  `send_to` text DEFAULT NULL,
  `sender` text DEFAULT NULL,
  `customer` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `amount`, `date_paid`, `send_to`, `sender`, `customer`, `email`) VALUES
(26, '600.000000', '2022-05-16 11:43:55', '1652701354258', 'gcb', '1652701354258', 'gcb@gmail.com'),
(28, '100.000000', '2022-05-16 01:55:10', '1652701354258', 'gcb', '1652701354258', 'gcb@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text DEFAULT NULL,
  `last_name` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `number` varchar(17) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `id_number` text DEFAULT NULL,
  `balance` decimal(18,6) DEFAULT NULL,
  `account_number` text DEFAULT NULL,
  `date_joined` text DEFAULT NULL,
  `secret` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `number`, `address`, `id_number`, `balance`, `account_number`, `date_joined`, `secret`) VALUES
(21, 'Duncan', 'Danful', 'danfulduncan@gmail.com', '+233209094359', 'Saint Anthony', '3453664', '700.000000', '1652701354258', '2022-05-16 11:42:34', 'daUxo.Qa8TFIk'),
(22, 'Andrea', 'FairLady', 'kofi@gmail.com', '+233209094359', 'Saint Anthony', '4335354', '0.000000', '1652701499114', '2022-05-16 11:44:59', 'koRWRfrwxcht.');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
