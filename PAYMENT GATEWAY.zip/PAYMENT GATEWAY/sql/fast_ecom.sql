-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 18, 2022 at 07:29 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fast_ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `ad_pass`
--

DROP TABLE IF EXISTS `ad_pass`;
CREATE TABLE IF NOT EXISTS `ad_pass` (
  `pass` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_pass`
--

INSERT INTO `ad_pass` (`pass`) VALUES
('1');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `sizes` text DEFAULT NULL,
  `colours` text DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `number` varchar(100) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `bus` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `sizes`, `colours`, `quantity`, `date`, `name`, `number`, `location`, `bus`) VALUES
(66, NULL, 83, '', '', 1, '2022-05-16 11:55:07', 'Duncan Danful', '+233209094359', 'Accra-Ghana', 'St. Anthony'),
(65, NULL, 82, '', '', 1, '2022-05-16 11:30:27', 'Duncan Danful', '+233209094359', 'Accra-Ghana', 'St. Anthony'),
(64, NULL, 83, '', '', 1, '2022-05-16 11:30:27', 'Duncan Danful', '+233209094359', 'Accra-Ghana', 'St. Anthony');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product` varchar(100) DEFAULT NULL,
  `categories` varchar(100) DEFAULT NULL,
  `sub` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `colours` text DEFAULT NULL,
  `sizes` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `img1` text DEFAULT NULL,
  `img2` text DEFAULT NULL,
  `type` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product`, `categories`, `sub`, `brand`, `price`, `colours`, `sizes`, `description`, `img1`, `img2`, `type`) VALUES
(74, 'Phone', 'Best deals', 'Discounted', 'Nike', 200, 'Red', '78', 'This is cool', '../product_images/_1626132462apple-iphone-11-pro-max-.jpg', '../product_images/_1626132462apple-iphone-x-new-1.jpg', 'Retail'),
(75, 'Coke', 'Best deals', 'Discounted', 'cool men', 100, 'inner', 'yh', 'yh', '../product_images/_162614490341LWqoFBfgL._AC_.jpg', '', 'Retail'),
(76, 'Accer Laptop', 'Best deals', 'Discounted', 'Accer', 900, 'Red', 'great', 'yh', '../product_images/_16261797660e4847162d4e2e4e4440e650208b794b.jpeg', '../product_images/_1626179766apple_z0vq_mrqy2_03_27_imac_with_retina_1566424414000_1468584.jpg', 'Wholesale'),
(77, 'Accer Laptop2', 'Best deals', 'Discounted', 'Accer', 900, 'This is incredibly beautiful', '78', 'And amazingly huge', '../product_images/_1626179874Apple-iPhone7-MatBlack-1-3x.jpg', '../product_images/_1626179874image.jpg', 'Retail'),
(78, 'Accer Laptop with cool features', 'Best deals', 'Discounted', 'Nike', 200, 'Green', '89', 'yellow', '../product_images/_1626180894ca-uhdtv-nu8000-un49nu8000fxzc-rperspectiveblack-94542995.jpeg', '', 'Retail'),
(79, 'Accer Laptope', 'Gaming accessories', 'Game pads', 'Nike', 200, 'black', '78', 'great', '../product_images/_1626272565001226_01_3.png', '', 'Retail'),
(80, 'good', 'Electronics', 'Sound bar', 'cool men', 200, 'Red', '56', 'this is very huge', '../product_images/_1627242144ms.jpg', '', 'Wholesale'),
(81, 'Droodle4', 'Pet feeds', 'All feeds', 'Droodle', 100, 'this is', 'great', 'Somem', '../product_images/_1648211169bitcoins.jpg', '', 'Wholesale'),
(82, 'Droodle', 'Men shirts', 'All short', 'Droodle', 100, 'ojjo', 'bbk', 'kkbk', '../product_images/_1650330765PHOTO-2022-03-21-07-25-14-1.jpg', '../product_images/_1650330765PHOTO-2022-03-21-07-25-14-2.jpg', 'Wholesale'),
(83, 'Classic men shirt', 'Men shirts', 'All short', 'Dolche Gabbana', 100, 'Green', '34', 'This is a great shirt for men', '../product_images/_16527003520bfdd6882b6b69e318e00b86d1a13f22--express-men-mens-grooming.jpg', '', 'Wholesale'),
(84, 'Watches', 'Other products', 'All feeds', 'Richard Mill', 400, 'Black', 'medium', 'its the best among all', '../product_images/_1652845471watch.png', '', 'Retail'),
(91, 'ladies shoes', 'Other products', '', 'Puma', 150, 'red shade', 'small', 'hight quality', '../product_images/_1652846993ladies.png', '', 'Retail'),
(86, 'men shoes', 'Men shoes', 'All shoes', 'LMXC', 500, 'lack shade', 'medium', 'its discounted', '../product_images/_1652846620men.png', '', 'Wholesale');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `number` varchar(15) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `city` varchar(10) DEFAULT NULL,
  `town` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `number`, `password`, `city`, `town`) VALUES
(17, 'Duncan Danful', 'danfulduncan@gmail.com', '0209094359', 'Duncan16', 'Accra', 'Dansoman'),
(18, 'andy OB', 'andyob@gmail.com', '3678765434', '1234', 'accra', 'dc');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
